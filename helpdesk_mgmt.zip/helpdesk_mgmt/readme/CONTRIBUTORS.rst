* `Domatix <https://www.domatix.com>`_:

  * Carlos Martínez
  * Catalin Airimitoaie
  * Álvaro López
  * Samuel Calvo

* `Adaptive City <https://www.adaptivecity.com>`_:

  * Aitor Bouzas

* `SDi Soluciones, S.L. <https://www.sdi.es>`_:

  * Oscar Soto
  * Jorge Luis Quinteros

* `C2i Change 2 improve <http://www.c2i.es>`_:

  * Eduardo Magdalena <emagdalena@c2i.es>

* `Factor Libre <https://factorlibre.com>`_:

  * María Alhambra
  * Daniel Cano

* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza

* `ID42 Sistemas <https://www.id42.com.br>`_:

  * Marcel Savegnago
  * Eduardo Aparício

* `Obertix <https://www.obertix.net>`_:

  * Vicent Cubells

* `Solvos <https://www.solvos.es>`_:

  * David Alonso
