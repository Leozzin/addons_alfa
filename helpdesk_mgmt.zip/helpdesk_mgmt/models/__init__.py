from . import helpdesk_ticket
from . import helpdesk_ticket_stage
from . import helpdesk_ticket_tag
from . import helpdesk_ticket_channel
from . import helpdesk_ticket_category
from . import helpdesk_ticket_team
from . import res_partner
